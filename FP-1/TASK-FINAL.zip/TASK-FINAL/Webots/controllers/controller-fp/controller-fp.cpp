// Template FP-1
// Referensi model robot: https://webots.cloud/run?version=R2025a&url=https%3A%2F%2Fgithub.com%2Fcyberbotics%2Fwebots%2Fblob%2Freleased%2Fprojects%2Frobots%2Frobotis%2Fdarwin-op%2Fprotos%2FRobotisOp2.proto
// Referensi Api Function: https://cyberbotics.com/doc/reference/nodes-and-api-functions

#include <iostream>
#include <fstream>
#include <map>
#include <string>
#include <webots/Motor.hpp>
#include <webots/PositionSensor.hpp>
#include <webots/Robot.hpp>
#include <webots/Receiver.hpp>
#include <nlohmann/json.hpp>

namespace wb = webots;
using json = nlohmann::json;

// Fungsi baca file JSON
json loadJSON(const std::string& path) {
    std::ifstream file(path);
    if (!file.is_open()) {
        std::cerr << "[ERROR] Tidak bisa membuka file JSON: " << path << std::endl;
        return {};
    }
    json data;
    file >> data;
    std::cout << "[SUCCESS] JSON pose berhasil dibaca: " << path << std::endl;
    return data;
}

// Fungsi menerapkan pose ke motor humanoid
void applyPose(const std::string& posePath,
               std::map<std::string, wb::Motor*>& motors,
               wb::Robot* robot,
               int timeStep) {
    json poseData = loadJSON(posePath);
    if (poseData.empty()) return;

    std::cout << "\n[POSE] Applying: " << poseData["name"] << std::endl;

    auto poseGroups = poseData["pose_group"];
    for (auto& group : poseGroups) {
        for (auto& pose : group["pose"]) {
            auto posisi = pose["posisi"];
            if (posisi.size() != motors.size()) {
                std::cerr << "[WARNING] Jumlah motor dan posisi tidak cocok!" << std::endl;
                return;
            }

            // interpolasi halus dari posisi sekarang ke target
            const int steps = 300; // makin besar makin halus
            for (int s = 0; s < steps; s++) {
                int i = 0;
                for (auto& motorPair : motors) {
                    double current = motorPair.second->getTargetPosition();
                    double target = posisi[i];
                    double smooth = current + 0.02 * (target - current);
                    motorPair.second->setPosition(smooth);
                    i++;
                }
                robot->step(timeStep);
            }

            // akhirnya set ke posisi target penuh
            int i = 0;
            for (auto& motorPair : motors) {
                motorPair.second->setPosition(posisi[i]);
                i++;
            }
            for (int i = 0; i < 20; i++) robot->step(timeStep);
        }
    }
}


// Main Program (Receiver dari ESP32)
int main(int argc, char** argv) {
    wb::Robot* robot = new wb::Robot();
    const int timeStep = static_cast<int>(robot->getBasicTimeStep());

    wb::Receiver* receiver = robot->getReceiver("receiver");
    receiver->enable(timeStep);
    // Map to store all motors
    std::map<std::string, wb::Motor*> motors;
    std::map<std::string, wb::PositionSensor*> positionSensors;

    const char* motorNames[] = {
        // Head motors
        "Head", "Neck",

        "ShoulderL", "ShoulderR",
        "ArmUpperL", "ArmUpperR",
        "ArmLowerL", "ArmLowerR",

        // Paha Z(Belok)
        "PelvYL", "PelvYR",

        // Paha X(Miring)
        "PelvL", "PelvR",

        // Paha atas Y(gerak depan / belakang)
        "LegUpperL", "LegUpperR",

        // Lutut
        "LegLowerL", "LegLowerR",

        // Tumit
        "AnkleL", "AnkleR",

        // Tumit X(miring)
        "FootL", "FootR"};

   for (auto name : motorNames) {
        wb::Motor* motor = robot->getMotor(name);
        if (motor) motors[name] = motor;
    }

    applyPose("../../poses/pose-berdiri.json", motors, robot, timeStep);

    std::cout << "\n[INFO] Menunggu perintah dari ESP32..." << std::endl;

    while (robot->step(timeStep) != -1) {
        if (receiver->getQueueLength() > 0) {
            const void* data = receiver->getData();
            std::string command((const char*)data, receiver->getDataSize());
            receiver->nextPacket();

            std::cout << "[RECEIVED] Perintah: " << command << std::endl;

            std::string posePath;
            if (command == "W") posePath = "../../poses/pose-jalan-maju.json";
            else if (command == "S") posePath = "../../poses/pose-jalan-mundur.json";
            else if (command == "A") posePath = "../../poses/pose-geser-kiri.json";
            else if (command == "D") posePath = "../../poses/pose-geser-kanan.json";
            else if (command == "Q") posePath = "../../poses/pose-belok-kiri.json";
            else if (command == "E") posePath = "../../poses/pose-belok-kanan.json";
            else if (command == "C") posePath = "../../poses/pose-berdiri.json";
            else if (command == "Z") posePath = "../../poses/pose-jongkok.json";
            else if (command == "F") posePath = "../../poses/pose-salam.json";
            else std::cout << "[WARNING] Perintah tidak dikenal!\n";

            if (!posePath.empty()) applyPose(posePath, motors, robot, timeStep);
        }
    }

    std::cout << "[INFO] Controller aktif dan menjaga pose..." << std::endl;
    while (robot->step(timeStep) != -1) {
  // tetap hidup supaya tidak nyungsep
}
    delete robot;
    return 0;

}