#include <esp_now.h>
#include <WiFi.h>

// MAC address receiver (sesuai ketentuan)
uint8_t receiverAddress[] = {0x24, 0x0A, 0xC4, 0x0A, 0x10, 0x11};

// Struktur data pesan yang dikirim dari Transmitter
typedef struct struct_message {
  char command[10];  // perintah dari keyboard (misalnya: "W", "A", "S", "D", "Q", "E", "C", "V")
} struct_message;

// Variabel global untuk menyimpan pesan
struct_message receivedMessage;

// Callback ketika data diterima
void onDataReceive(const uint8_t *mac, const uint8_t *incomingData, int len) {
  memcpy(&receivedMessage, incomingData, sizeof(receivedMessage));

  Serial.print("Perintah diterima: ");
  Serial.println(receivedMessage.command);

  // Kirim ke Webots via serial (misal dikirim ke laptop)
  // Bisa juga ditambah format JSON kalau kamu mau parsing di Webots
  Serial.print("Kirim ke Webots: ");
  Serial.println(receivedMessage.command);
}

void setup() {
  // Mulai Serial agar bisa komunikasi dengan Webots/laptop
  Serial.begin(115200);

  // Mode WiFi station (dibutuhkan untuk ESP-NOW)
  WiFi.mode(WIFI_STA);

  // Inisialisasi ESP-NOW
  if (esp_now_init() != ESP_OK) {
    Serial.println("Error initializing ESP-NOW");
    return;
  }

  // Registrasi callback
  esp_now_register_recv_cb(onDataReceive);

  Serial.println("Receiver siap menerima perintah dari keyboard...");
}

void loop() {
  // Tidak perlu apa-apa di loop karena callback onDataReceive akan dipanggil otomatis
}
